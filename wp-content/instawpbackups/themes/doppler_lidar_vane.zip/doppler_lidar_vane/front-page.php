<?php
/**
 * The front page template
 *
 * @package doppler_lidar
 */

get_header();

$theme  = get_template_directory_uri();
$status = isset( $_GET['campaign'] ) ? sanitize_key( wp_unslash( $_GET['campaign'] ) ) : '';
?>

<main id="primary" class="site-main">

	<section class="wd-hero wd-container" aria-labelledby="hero-title">
		<div class="wd-hero__copy">
			<div class="wd-kicker">
				<span class="wd-label wd-kicker__text"><?php esc_html_e( 'Turnkey Solution', 'doppler_lidar' ); ?></span>
				<span class="wd-kicker__line" aria-hidden="true"></span>
			</div>
			<h1 id="hero-title" class="wd-headline-xl">
				<?php esc_html_e( 'Bankable wind data.', 'doppler_lidar' ); ?><br>
				<?php esc_html_e( 'Delivered turnkey.', 'doppler_lidar' ); ?>
			</h1>
			<p class="wd-body wd-lede--narrow">
				<?php esc_html_e( 'Complete LiDAR measurement campaigns for onshore wind projects — from deployment and monitoring to quality-controlled data delivery.', 'doppler_lidar' ); ?>
			</p>
			<div class="wd-hero__actions">
				<a class="wd-btn wd-btn--primary wd-btn--lg" href="#contact"><?php esc_html_e( 'Request a Campaign', 'doppler_lidar' ); ?></a>
				<a class="wd-btn wd-btn--ghost wd-btn--lg" href="#contact">
					<?php esc_html_e( 'Check fleet availability', 'doppler_lidar' ); ?>
					<span class="material-symbols-outlined" aria-hidden="true">arrow_forward</span>
				</a>
			</div>
		</div>
		<div class="wd-hero__media">
			<div class="wd-schematic">
				<span class="wd-schematic__corner wd-schematic__corner--tl" aria-hidden="true"></span>
				<span class="wd-schematic__corner wd-schematic__corner--tr" aria-hidden="true"></span>
				<span class="wd-schematic__corner wd-schematic__corner--bl" aria-hidden="true"></span>
				<span class="wd-schematic__corner wd-schematic__corner--br" aria-hidden="true"></span>
				<img src="<?php echo esc_url( $theme . '/images/lidar.svg' ); ?>" alt="<?php esc_attr_e( 'ZX-300e LiDAR Unit', 'doppler_lidar' ); ?>">
			</div>
		</div>
	</section>

	<section class="wd-strip" aria-label="<?php esc_attr_e( 'Capabilities', 'doppler_lidar' ); ?>">
		<div class="wd-container">
			<div class="wd-strip__grid">
				<div class="wd-strip__item">
					<span class="material-symbols-outlined" aria-hidden="true">verified</span>
					<div>
						<span class="wd-label"><?php esc_html_e( 'Standard', 'doppler_lidar' ); ?></span>
						<span class="wd-strip__title"><?php esc_html_e( 'IEC-Classified LiDAR Technology', 'doppler_lidar' ); ?></span>
					</div>
				</div>
				<div class="wd-strip__item">
					<span class="material-symbols-outlined" aria-hidden="true">monitoring</span>
					<div>
						<span class="wd-label"><?php esc_html_e( 'Uptime', 'doppler_lidar' ); ?></span>
						<span class="wd-strip__title"><?php esc_html_e( '24/7 Remote Monitoring', 'doppler_lidar' ); ?></span>
					</div>
				</div>
				<div class="wd-strip__item">
					<span class="material-symbols-outlined" aria-hidden="true">precision_manufacturing</span>
					<div>
						<span class="wd-label"><?php esc_html_e( 'Reliability', 'doppler_lidar' ); ?></span>
						<span class="wd-strip__title"><?php esc_html_e( 'Autonomous Operation', 'doppler_lidar' ); ?></span>
					</div>
				</div>
				<div class="wd-strip__item">
					<span class="material-symbols-outlined" aria-hidden="true">analytics</span>
					<div>
						<span class="wd-label"><?php esc_html_e( 'Integrity', 'doppler_lidar' ); ?></span>
						<span class="wd-strip__title"><?php esc_html_e( 'Quality-Controlled Data', 'doppler_lidar' ); ?></span>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="wd-section wd-section--auto" aria-labelledby="problem-title">
		<div class="wd-container">
			<div class="wd-center">
				<h2 id="problem-title" class="wd-headline-lg"><?php esc_html_e( 'Reliable data. Less complexity.', 'doppler_lidar' ); ?></h2>
				<p class="wd-body">
					<?php esc_html_e( 'A successful wind measurement campaign requires more than a LiDAR. We combine measurement technology, autonomous power, remote monitoring and wind engineering expertise into one managed service.', 'doppler_lidar' ); ?>
				</p>
			</div>
			<div class="wd-feature-row">
				<div>
					<h3 class="wd-label"><?php esc_html_e( 'Complete Campaign', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Planning, deployment, commissioning and decommissioning.', 'doppler_lidar' ); ?></p>
				</div>
				<div class="wd-feature-row__mid">
					<h3 class="wd-label"><?php esc_html_e( 'Continuous Monitoring', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Remote monitoring of equipment performance and incoming data.', 'doppler_lidar' ); ?></p>
				</div>
				<div>
					<h3 class="wd-label"><?php esc_html_e( 'Quality-Controlled Data', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Structured datasets and reporting ready for your engineering workflow.', 'doppler_lidar' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<section id="how-it-works" class="wd-section wd-section--auto" aria-labelledby="how-title">
		<div class="wd-container">
			<h2 id="how-title" class="wd-headline-lg wd-section-title"><?php esc_html_e( 'From site to dataset.', 'doppler_lidar' ); ?></h2>
			<div class="wd-timeline">
				<div class="wd-timeline__line" aria-hidden="true"></div>
				<div class="wd-step">
					<span class="wd-step__dot" aria-hidden="true"><span></span></span>
					<h3 class="wd-label wd-step__label"><?php esc_html_e( '01 — Plan', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'We define measurement objectives, heights, campaign duration and site requirements.', 'doppler_lidar' ); ?></p>
				</div>
				<div class="wd-step">
					<span class="wd-step__dot" aria-hidden="true"><span></span></span>
					<h3 class="wd-label wd-step__label"><?php esc_html_e( '02 — Deploy', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'We transport, install and commission the LiDAR and autonomous power system.', 'doppler_lidar' ); ?></p>
				</div>
				<div class="wd-step">
					<span class="wd-step__dot" aria-hidden="true"><span></span></span>
					<h3 class="wd-label wd-step__label"><?php esc_html_e( '03 — Monitor', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'System performance and incoming measurements are continuously monitored.', 'doppler_lidar' ); ?></p>
				</div>
				<div class="wd-step">
					<span class="wd-step__dot" aria-hidden="true"><span></span></span>
					<h3 class="wd-label wd-step__label"><?php esc_html_e( '04 — Deliver', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Quality-controlled wind data and campaign reporting are delivered throughout the project.', 'doppler_lidar' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<section id="data-quality" class="wd-section wd-section--auto wd-section--border" aria-labelledby="quality-title">
		<div class="wd-container wd-two">
			<div class="wd-two__copy">
				<h2 id="quality-title" class="wd-headline-lg"><?php esc_html_e( 'Data you can build decisions on.', 'doppler_lidar' ); ?></h2>
				<p class="wd-body wd-lede--narrow"><?php esc_html_e( 'Wind measurements influence energy yield assessments, turbine selection and investment decisions. Campaign quality cannot be an afterthought.', 'doppler_lidar' ); ?></p>
				<ul class="wd-checklist">
					<li><span class="material-symbols-outlined" aria-hidden="true">check_circle</span><span><?php esc_html_e( 'IEC-classified LiDAR technology', 'doppler_lidar' ); ?></span></li>
					<li><span class="material-symbols-outlined" aria-hidden="true">description</span><span><?php esc_html_e( 'Documented commissioning', 'doppler_lidar' ); ?></span></li>
					<li><span class="material-symbols-outlined" aria-hidden="true">sensors</span><span><?php esc_html_e( 'Remote monitoring', 'doppler_lidar' ); ?></span></li>
					<li><span class="material-symbols-outlined" aria-hidden="true">rule</span><span><?php esc_html_e( 'Systematic quality control', 'doppler_lidar' ); ?></span></li>
					<li><span class="material-symbols-outlined" aria-hidden="true">history_edu</span><span><?php esc_html_e( 'Traceable campaign reporting', 'doppler_lidar' ); ?></span></li>
				</ul>
				<a class="wd-text-link" href="#data-quality">
					<?php esc_html_e( 'Explore our data quality process', 'doppler_lidar' ); ?>
					<span class="material-symbols-outlined" aria-hidden="true">arrow_forward</span>
				</a>
			</div>
			<div class="wd-window">
				<div class="wd-window__bar" aria-hidden="true">
					<span></span><span></span><span></span>
				</div>
				<div class="wd-window__body">
					<img src="<?php echo esc_url( $theme . '/images/dashboard.svg' ); ?>" alt="<?php esc_attr_e( 'Wind Data Analytics Dashboard', 'doppler_lidar' ); ?>">
				</div>
			</div>
		</div>
	</section>

	<section id="use-cases" class="wd-section wd-section--auto wd-section--border" aria-labelledby="usecases-title">
		<div class="wd-container">
			<h2 id="usecases-title" class="wd-headline-lg wd-section-title"><?php esc_html_e( 'Built for real wind projects.', 'doppler_lidar' ); ?></h2>
			<div class="wd-cases">
				<article class="wd-case">
					<span class="wd-case__num" aria-hidden="true">01</span>
					<span class="material-symbols-outlined" aria-hidden="true">assessment</span>
					<h3 class="wd-label"><?php esc_html_e( 'Wind Resource Assessment', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Collect wind measurements for greenfield project development.', 'doppler_lidar' ); ?></p>
				</article>
				<article class="wd-case">
					<span class="wd-case__num" aria-hidden="true">02</span>
					<span class="material-symbols-outlined" aria-hidden="true">height</span>
					<h3 class="wd-label"><?php esc_html_e( 'Met Mast Complement', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Extend measurement heights and improve understanding of the rotor-swept wind profile.', 'doppler_lidar' ); ?></p>
				</article>
				<article class="wd-case">
					<span class="wd-case__num" aria-hidden="true">03</span>
					<span class="material-symbols-outlined" aria-hidden="true">autorenew</span>
					<h3 class="wd-label"><?php esc_html_e( 'Repowering', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Measure wind conditions at modern turbine hub and rotor heights.', 'doppler_lidar' ); ?></p>
				</article>
				<article class="wd-case">
					<span class="wd-case__num" aria-hidden="true">04</span>
					<span class="material-symbols-outlined" aria-hidden="true">explore</span>
					<h3 class="wd-label"><?php esc_html_e( 'Site Investigation', 'doppler_lidar' ); ?></h3>
					<p class="wd-body"><?php esc_html_e( 'Quickly characterise prospective wind farm locations.', 'doppler_lidar' ); ?></p>
				</article>
			</div>
		</div>
	</section>

	<section id="technology" class="wd-section wd-section--auto wd-section--muted wd-section--border" aria-labelledby="tech-title">
		<div class="wd-container wd-two">
			<div class="wd-two__copy">
				<div class="wd-kicker wd-kicker--short">
					<span class="wd-kicker__rule" aria-hidden="true"></span>
					<span class="wd-label wd-kicker__text"><?php esc_html_e( 'Technology', 'doppler_lidar' ); ?></span>
				</div>
				<h2 id="tech-title" class="wd-headline-lg"><?php esc_html_e( 'Professional vertical profiling LiDAR', 'doppler_lidar' ); ?></h2>
				<p class="wd-body"><?php esc_html_e( 'Our campaigns use industry-proven Doppler LiDAR technology capable of measuring the wind profile across modern turbine rotor heights.', 'doppler_lidar' ); ?></p>
				<a class="wd-text-link" href="#technology">
					<?php esc_html_e( 'Explore the technology', 'doppler_lidar' ); ?>
					<span class="material-symbols-outlined" aria-hidden="true">arrow_forward</span>
				</a>
			</div>
			<div class="wd-placeholder">
				<span class="wd-schematic__corner wd-schematic__corner--inset-tl" aria-hidden="true"></span>
				<span class="wd-schematic__corner wd-schematic__corner--inset-tr" aria-hidden="true"></span>
				<span class="wd-schematic__corner wd-schematic__corner--inset-bl" aria-hidden="true"></span>
				<span class="wd-schematic__corner wd-schematic__corner--inset-br" aria-hidden="true"></span>
				<span class="material-symbols-outlined" aria-hidden="true">radar</span>
				<p class="wd-label"><?php esc_html_e( 'Vertical Wind Profiling System', 'doppler_lidar' ); ?></p>
			</div>
		</div>
	</section>

	<section id="sample-report" class="wd-section wd-section--auto wd-section--border" aria-labelledby="sample-title">
		<div class="wd-container wd-two wd-two--7-5">
			<div class="wd-two__copy">
				<div class="wd-kicker wd-kicker--short">
					<span class="wd-kicker__rule wd-kicker__rule--primary" aria-hidden="true"></span>
					<span class="wd-label wd-kicker__text wd-kicker__text--primary"><?php esc_html_e( 'Sample Campaign Report', 'doppler_lidar' ); ?></span>
				</div>
				<h2 id="sample-title" class="wd-headline-lg"><?php esc_html_e( 'And we show a real excerpt on the homepage.', 'doppler_lidar' ); ?></h2>
				<p class="wd-body"><?php esc_html_e( 'Our reporting provides full transparency into campaign performance, ensuring every data point is verified and traceable to international standards.', 'doppler_lidar' ); ?></p>
				<ul class="wd-checklist wd-checklist--compact">
					<li><span class="material-symbols-outlined" aria-hidden="true">analytics</span><span><?php esc_html_e( 'Monthly statistics', 'doppler_lidar' ); ?></span></li>
					<li><span class="material-symbols-outlined" aria-hidden="true">settings_input_component</span><span><?php esc_html_e( 'Equipment status', 'doppler_lidar' ); ?></span></li>
					<li><span class="material-symbols-outlined" aria-hidden="true">fact_check</span><span><?php esc_html_e( 'QC observations', 'doppler_lidar' ); ?></span></li>
				</ul>
				<a class="wd-btn wd-btn--primary wd-btn--lg" href="#sample-report"><?php esc_html_e( 'View Sample Campaign Report', 'doppler_lidar' ); ?></a>
			</div>
			<div class="wd-report">
				<div class="wd-report__top">
					<div>
						<p class="wd-report__brand"><?php esc_html_e( 'WindVerity', 'doppler_lidar' ); ?></p>
						<p class="wd-caption wd-caption--caps"><?php esc_html_e( 'Campaign Status Report', 'doppler_lidar' ); ?></p>
					</div>
					<div class="wd-report__metric">
						<p class="wd-caption wd-caption--caps"><?php esc_html_e( 'Availability', 'doppler_lidar' ); ?></p>
						<p class="wd-report__value">98.7%</p>
					</div>
				</div>
				<div class="wd-report__grid">
					<div class="wd-rose" aria-hidden="true">
						<span class="wd-rose__axis wd-rose__axis--h"></span>
						<span class="wd-rose__axis wd-rose__axis--v"></span>
						<div class="wd-rose__rings">
							<span class="wd-rose__ring wd-rose__ring--outer"></span>
							<span class="wd-rose__ring wd-rose__ring--mid"></span>
							<span class="wd-rose__ring wd-rose__ring--inner"></span>
							<svg viewBox="0 0 100 100">
								<polygon fill="currentColor" points="50,10 70,30 85,50 70,70 50,90 30,70 15,50 30,30"></polygon>
							</svg>
							<span class="wd-rose__dir wd-rose__dir--n">N</span>
							<span class="wd-rose__dir wd-rose__dir--e">E</span>
							<span class="wd-rose__dir wd-rose__dir--s">S</span>
							<span class="wd-rose__dir wd-rose__dir--w">W</span>
						</div>
						<p class="wd-caption wd-caption--caps"><?php esc_html_e( 'Wind Rose Analysis', 'doppler_lidar' ); ?></p>
					</div>
					<div class="wd-report__stats">
						<div>
							<p class="wd-caption wd-caption--caps"><?php esc_html_e( 'Mean Wind Speed', 'doppler_lidar' ); ?></p>
							<p class="wd-data">8.42 m/s</p>
						</div>
						<div>
							<p class="wd-caption wd-caption--caps"><?php esc_html_e( 'Turbulence Intensity', 'doppler_lidar' ); ?></p>
							<p class="wd-data">0.124</p>
						</div>
						<div>
							<p class="wd-caption wd-caption--caps"><?php esc_html_e( 'TI Class', 'doppler_lidar' ); ?></p>
							<p class="wd-data"><?php esc_html_e( 'IEC Class A', 'doppler_lidar' ); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="contact" class="wd-section wd-section--auto wd-section--border wd-contact" aria-labelledby="contact-title">
		<div class="wd-container wd-contact__inner">
			<h2 id="contact-title" class="wd-headline-lg"><?php esc_html_e( 'Tell us about your project.', 'doppler_lidar' ); ?></h2>
			<p class="wd-body">
				<?php esc_html_e( 'Send us the location and expected campaign start. We\'ll take it from there.', 'doppler_lidar' ); ?>
			</p>

			<?php if ( 'sent' === $status ) : ?>
				<p class="wd-notice"><?php esc_html_e( 'Thank you. We received your campaign request and will be in touch.', 'doppler_lidar' ); ?></p>
			<?php elseif ( 'error' === $status ) : ?>
				<p class="wd-notice wd-notice--error"><?php esc_html_e( 'Please fill in your name and a valid work email, then try again.', 'doppler_lidar' ); ?></p>
			<?php endif; ?>

			<form class="wd-form" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php wp_nonce_field( 'doppler_lidar_campaign', 'doppler_lidar_campaign_nonce' ); ?>
				<p class="wd-hp" aria-hidden="true">
					<label><?php esc_html_e( 'Company website', 'doppler_lidar' ); ?>
						<input type="text" name="company_website" tabindex="-1" autocomplete="off">
					</label>
				</p>
				<div class="wd-form__row">
					<div class="wd-field">
						<label class="wd-label" for="campaign_name"><?php esc_html_e( 'Name', 'doppler_lidar' ); ?></label>
						<input id="campaign_name" name="campaign_name" type="text" required>
					</div>
					<div class="wd-field">
						<label class="wd-label" for="campaign_email"><?php esc_html_e( 'Work Email', 'doppler_lidar' ); ?></label>
						<input id="campaign_email" name="campaign_email" type="email" required>
					</div>
					<div class="wd-field">
						<label class="wd-label" for="campaign_location"><?php esc_html_e( 'Project Location', 'doppler_lidar' ); ?></label>
						<input id="campaign_location" name="campaign_location" type="text" required>
					</div>
					<div class="wd-field">
						<label class="wd-label" for="campaign_start"><?php esc_html_e( 'Expected Start', 'doppler_lidar' ); ?></label>
						<input id="campaign_start" name="campaign_start" type="text" required>
					</div>
				</div>
				<div class="wd-field">
					<label class="wd-label" for="campaign_notes"><?php esc_html_e( 'Anything Else? (Optional)', 'doppler_lidar' ); ?></label>
					<textarea id="campaign_notes" name="campaign_notes" rows="3"></textarea>
				</div>
				<div class="wd-form__submit">
					<button class="wd-btn wd-btn--primary wd-btn--lg" type="submit"><?php esc_html_e( 'Request a Campaign', 'doppler_lidar' ); ?></button>
				</div>
			</form>
		</div>
	</section>

</main>

<?php
get_footer();

<?php
/**
 * doppler_lidar functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package doppler_lidar
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.3.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function doppler_lidar_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on doppler_lidar, use a find and replace
		* to change 'doppler_lidar' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'doppler_lidar', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'doppler_lidar' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'doppler_lidar_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'doppler_lidar_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function doppler_lidar_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'doppler_lidar_content_width', 1200 );
}
add_action( 'after_setup_theme', 'doppler_lidar_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function doppler_lidar_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'doppler_lidar' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'doppler_lidar' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'doppler_lidar_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function doppler_lidar_scripts() {
	wp_enqueue_style(
		'doppler_lidar-fonts',
		'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap',
		array(),
		null
	);
	wp_enqueue_style(
		'doppler_lidar-icons',
		'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'doppler_lidar-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_enqueue_style(
		'doppler_lidar-main',
		get_template_directory_uri() . '/css/main.css',
		array( 'doppler_lidar-style', 'doppler_lidar-fonts' ),
		_S_VERSION
	);

	wp_enqueue_script( 'doppler_lidar-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'doppler_lidar_scripts' );

/**
 * Fallback primary navigation matching the homepage mockup.
 */
function doppler_lidar_primary_menu_fallback() {
	$home = home_url( '/' );
	$items = array(
		'#technology'    => __( 'LiDAR Systems', 'doppler_lidar' ),
		'#how-it-works'  => __( 'Measurement', 'doppler_lidar' ),
		'#data-quality'  => __( 'Analytics', 'doppler_lidar' ),
		'#use-cases'     => __( 'Compliance', 'doppler_lidar' ),
		'#contact'       => __( 'Contact', 'doppler_lidar' ),
	);
	echo '<ul id="primary-menu" class="nav-menu">';
	foreach ( $items as $hash => $label ) {
		printf(
			'<li><a href="%s">%s</a></li>',
			esc_url( $home . $hash ),
			esc_html( $label )
		);
	}
	echo '</ul>';
}

/**
 * Handle homepage campaign request form.
 */
function doppler_lidar_handle_campaign_request() {
	if ( ! isset( $_POST['doppler_lidar_campaign_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['doppler_lidar_campaign_nonce'] ) ), 'doppler_lidar_campaign' ) ) {
		return;
	}

	if ( ! empty( $_POST['company_website'] ) ) {
		wp_safe_redirect( home_url( '/#contact' ) );
		exit;
	}

	$name     = isset( $_POST['campaign_name'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_name'] ) ) : '';
	$email    = isset( $_POST['campaign_email'] ) ? sanitize_email( wp_unslash( $_POST['campaign_email'] ) ) : '';
	$location = isset( $_POST['campaign_location'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_location'] ) ) : '';
	$start    = isset( $_POST['campaign_start'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_start'] ) ) : '';
	$notes    = isset( $_POST['campaign_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['campaign_notes'] ) ) : '';

	if ( '' === $name || ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'campaign', 'error', home_url( '/' ) ) . '#contact' );
		exit;
	}

	$lines = array(
		'Name: ' . $name,
		'Email: ' . $email,
		'Project location: ' . $location,
		'Expected start: ' . $start,
		'Notes: ' . $notes,
	);

	$sent = wp_mail(
		get_option( 'admin_email' ),
		sprintf( '[WindVerity] Campaign request from %s', $name ),
		implode( "\n", $lines ),
		array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $email )
	);

	wp_safe_redirect( add_query_arg( 'campaign', $sent ? 'sent' : 'error', home_url( '/' ) ) . '#contact' );
	exit;
}
add_action( 'template_redirect', 'doppler_lidar_handle_campaign_request' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

